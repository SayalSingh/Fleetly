//
//  ExpenseType.swift
//  FleetlyDriver
//
//  Created by Sayal Singh on 25/04/25.
//

import Foundation

enum ExpenseType {
    case fuel
    case toll
    case misc
    case none
}
